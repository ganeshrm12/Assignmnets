#include<stdio.h>
#include<fcntl.h>
#include<string.h>

int main(int argc, char *argv[20]){
 
 
    char Fname[20];
    char mode[20];
    
    printf("Enter file name u want to open : ");
    scanf("%s",&Fname);
    
    printf("Enter the mode of file : ");
    scanf("%s",&mode);
    
    printf("Entered file name and mode of file is : %s and %s\n",Fname,mode);
    int fd = 0;
    
    if(strcmp(mode,"read")==0){
      
      fd = open(Fname,O_RDONLY);
      
      if(fd==-1){
      printf("Unable to open in READ mode\n");
      return -1;
      }
      printf("File opened in READ mode\n");
      return 0; 
    }else if(strcmp(mode,"write")==0){
       
       fd = open(Fname,O_WRONLY);
       if(fd==-1){
      printf("Unable to open in WRITE mode\n");
      return -1;
      }
       printf("File opened in WRITE mode\n");
       return 0;
    }else if(strcmp(mode,"create")==0){
      
       fd = open(Fname,O_CREAT);
       if(fd==-1){
      printf("Unable to open in CREAT mode\n");
      return -1;
      }
       printf("File Created successfully\n");
       return 0;
    }else if(strcmp(mode,"read+write")==0){
     
       fd = open(Fname, O_RDWR);
       if(fd==-1){
      printf("Unable to open in READ+WRITE mode\n");
      return -1;
      }
       printf("File opened in READ and WRITE mode\n");
       return 0;
    }
    
    printf("Unable to open file\n");
    return -1;    
    
}
