#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>


int main(int argc, char *argv[]){

 
 char Fname[20];
 char mode[20];
 
 printf("Enter file name : ");
 scanf("%s",&Fname);
 printf("Enter the mode of file : ");
 scanf("%s",&mode);
 
 int accessmode = 0;
 
 
 if(strcmp(mode,"read")==0){
 
 accessmode = R_OK;
   
 }else if(strcmp(mode,"write")==0){
  
  accessmode = W_OK;
 
 }else if(strcmp(mode,"execute")==0){
 
   accessmode = X_OK;
 }
 
 if(access(Fname,accessmode)<0){
 
    printf("Unable to open file %s in %s mode\n",Fname, mode);
    
 }else{
 
    printf("File %s is successfuly opened in %s mode\n",Fname, mode);
 }
 
 return 0;
   
}
