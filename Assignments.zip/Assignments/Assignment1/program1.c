#include<stdio.h>
#include<fcntl.h>

int main(int argc, char * argv[]){

 char Fname[20];
 
 printf("Enter file name you want to open : ");
 scanf("%s",&Fname);
 int fd = 0;
 
 printf("Entered file name : %s\n", Fname);
 
 fd = open(Fname, O_RDONLY);
 
 if(fd==-1){
   
   printf("Unable to open file\n");
   return -1;
 }
 
 printf("File opened successfully\n");
 
 return 0;
}


