#include<stdio.h>
#include<sys/stat.h>
#include<string.h>
#include<time.h>

int main(int argc, char *argv[]){

 
 char Fname[20];
 
 printf("Enter file name : ");
 scanf("%s",&Fname);
 
 
 struct stat s;
 
 
 stat(Fname,&s);
 
 printf("File Name : %s\n",Fname);
 printf("File Size : %d\n",s.st_size);
 printf("ID of device containing file : %d\n",s.st_dev);
 printf("inode number : %d\n",s.st_ino);
 printf("protection : %08X\n",s.st_mode);
 printf("user ID of owner : %d\n",s.st_uid);
 printf("group ID of owner : %d\n",s.st_gid);
 printf("blocksize for file system I/O  : %d\n",s.st_blksize);
 printf("number of blocks allocated : %d\n",s.st_blocks);
 printf("time of last access : %s",ctime(&s.st_atime));
 printf("time of last modification  : %s",ctime(&s.st_mtime));
 printf("time of last status change  : %s",ctime(&s.st_ctime));
  
 return 0;
   
}
