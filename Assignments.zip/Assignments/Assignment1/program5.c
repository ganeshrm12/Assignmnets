#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>


int main(int argc, char *argv[]){

 
 char Fname[20];
 int bytes = 0;
 
 printf("Enter file name : ");
 scanf("%s",&Fname);
 printf("Enter the no of bytes u want to read from file : ");
 scanf("%d",&bytes);
 
 int fd = 0;
 fd = open(Fname,O_RDONLY);
 
 if(fd==-1){
 
    printf("unable to open file\n");
    return -1;
 }
 
 int returnbytes = 0;
 char Arr[20];
  
 returnbytes = read(fd,Arr,bytes);
 
 printf("Data from file is : \n");
 write(1,Arr,returnbytes);
 printf("\n");
 
 
 close(fd);
 
 return 0;
   
}
