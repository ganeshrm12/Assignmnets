#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>


int main(int argc, char *argv[]){


   DIR *dp = NULL;
   struct dirent * entry = NULL;
   char dName[20];
   struct stat sobj1;
  
   
   dp = opendir(argv[1]);
   
   if(dp==NULL){
   
     printf("Unable to open directory\n");
   }
   
   printf("Files as belows : \n");
   
    int size = 0;
    char largest_file[20];
    char name[30];
    
   while((entry = readdir(dp))!=NULL){
      
        sprintf(name,"%s/%s",argv[1],entry->d_name);
        stat(name,&sobj1);
        printf("%s \n",entry->d_name);
       
       if(S_ISREG(sobj1.st_mode)){ 
       
          if(size<sobj1.st_size){       
             size = sobj1.st_size;
             strcpy(largest_file,entry->d_name);
          }
       
       }
   }
   
   printf("largest size File name is %s and size is %d\n",largest_file,size);
   
   closedir(dp);
   return 0;
   
}
