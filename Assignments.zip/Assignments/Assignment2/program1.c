#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>

#define BLOCKSIZE 1024

int main(int argc, char *argv[]){

 
 char Fname[20];
 
 printf("Enter file name : ");
 scanf("%s",&Fname);
 
 int fd = 0;
 
 fd = open(Fname,O_RDONLY);
 
 if(fd==-1){
  
     printf("unable to open file\n");
 }
 
 char Buffer[BLOCKSIZE];
 
 int ret = 0;
 
 while((ret = read(fd,Buffer,sizeof(Buffer)))!=0){
    
     write(1,Buffer,ret);
 
 }
 return 0;
   
}
