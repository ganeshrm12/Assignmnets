#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>


#define BLOCKSIZE 1024

int main(int argc, char *argv[]){

 
 char Fname[20];
 int fd = 0;
 int ret = 0;
 char Buffer[BLOCKSIZE] = {'\0'};
 char str[20];
 
 printf("Enter file name : ");
 scanf("%s",&Fname);
 

 
 fd = open(Fname,O_RDWR);
 
 if(fd==-1){
  
     printf("unable to open file\n");
     return -1;
 }
 
 
 lseek(fd,-1,SEEK_END);
 
 printf("Enter string u want to  write in file : ");
 scanf("%s",&str);
 
 
 int no_bytes = strlen(str);
 
 ret = write(fd,str,no_bytes);
 //printf("==%d",ret);
 
 lseek(fd,0,SEEK_SET);
 
 while((ret = read(fd,Buffer,sizeof(Buffer)))!=0){
 
     write(1,Buffer,ret);
     memset(Buffer,0,sizeof(Buffer));
 }
 
 close(fd);

 return 0;
   
}
