#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>


int main(int argc, char * argv[]){


   char filename[20];
   int fd = 0;
   int offset = 0;
    
   printf("Enter name of file : \n");
   scanf("%s",&filename);
   printf("Enter offset ");
   scanf("%d",&offset);
   fd = open(filename,O_RDWR);
   
   if(fd==-1){
   
      printf("Unable to open file\n");
      return -1;
   }
   
   char buffer[1024];
   lseek(fd,0,SEEK_SET);
   int ret = 0;
   
   int fd1 = 0;
   fd1 = creat("tmp.txt",0777);
   int tmp_var = 0;
   
   while((ret = read(fd,buffer,sizeof(buffer)))!=0){
   
      
      if(ret>offset){
      
      write(fd1,buffer,offset); 
    //  printf("in if : tmp_var and ret %d and %d\n",tmp_var,ret); 
      break;
      
      }else if(tmp_var<=offset){
        write(fd1,buffer,ret); 
        break;
      }else{
         break;
      }
        tmp_var = tmp_var+ret;
       // printf("out if : tmp_var and ret %d and %d\n",tmp_var,ret);
   }
   
   rename("tmp.txt",filename);
   

  return 0;
  
}
