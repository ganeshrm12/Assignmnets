#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>
#include<string.h>


int main(int argc, char *argv[]){


       int ret = 0;
       ret  = mkdir(argv[1],0755);
       
       if(ret==-1){
       printf("uanble to create directory as its already present\n");
       }else{
       printf("Directory Created successfully with name %s and %d\n",argv[1],ret);
       }
       
       char name[30];
       
       int fd = 0;
       sprintf(name,"%s/%s",argv[1],argv[2]);
       fd = creat(name,0777);
       
       if(fd == -1){
       
          printf("ERROR\n");
          return -1;
       }
       
       printf("File Created successfully with name %s\n",argv[2]);
       
       close(fd);
       
   return 0;
   
}
