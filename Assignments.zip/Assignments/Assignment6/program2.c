#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>


int main(int argc, char * argv[]){


   char filename[20];
   int fd = 0;

   printf("Enter name of file : \n");
   scanf("%s",filename);
   
   fd = open(filename,O_RDWR);
   
   if(fd==-1){
   
      printf("Unable to open file\n");
      return -1;
   }
   
   char garbage[1024];
   lseek(fd,0,SEEK_END);
   int ret = 0;
   
   ret = write(fd,garbage,sizeof(garbage));
   
   printf("ret = %d\n",ret);

  return 0;
  
}
