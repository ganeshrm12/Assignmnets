did not understand question
