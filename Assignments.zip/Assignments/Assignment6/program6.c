#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>

int main(int argc, char * argv[]){

   DIR *dp = NULL;
   struct dirent *entry = NULL;
   struct stat sobj;
   
   char DirName[20];
   char filename[20];
   
   printf("Enter name of directory : \n");
   scanf("%s",DirName);
   printf("Enter name of file : \n");
   scanf("%s",filename);
   
   
   dp = opendir(DirName);
   if(dp==NULL){
    
     printf("unable to open directory\n");
     return -1;
     
   }
   char name[20];
   int fd = 0;
   
   sprintf(name,"%s/%s",DirName,filename);
   
   fd = open(name,O_RDWR);
   
   if(fd==-1){
   
      printf("Unable to open file\n");
      return -1;
   }
   
   char garbage[1024];
   
   int ret = 0;
   
   stat(name,&sobj);
   
   if(sobj.st_size<1024){
   lseek(fd,0,SEEK_END);
   ret = write(fd,garbage,sizeof(garbage));
   }else{
     truncate(name,0);
   }
   printf("ret = %d\n",ret);

  return 0;
  
}
