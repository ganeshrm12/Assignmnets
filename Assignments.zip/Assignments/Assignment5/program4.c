#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>

#define BLOCKSIZE 1024
int main(int argc, char *argv[]){


   DIR *dp = NULL;
   struct dirent *entry = NULL;
   struct stat sobj;
   
   char DirName[20];
   char filename[20];
   
   printf("Enter name of directory : \n");
   scanf("%s",DirName);
   printf("Enter name of combine data file : \n");
   scanf("%s",filename);
   
   
   dp = opendir(DirName);
   if(dp==NULL){
    
     printf("unable to open directory\n");
     return -1;
     
   }
   
   char name[20];
   
   int fd1 = 0;
   
    fd1 = creat(filename,0777);
    char buffer[BLOCKSIZE] = {'\0'};
    char tmp[100];
    int ret = 0;
    int fd2 = 0;
    
   while((entry = readdir(dp))!=NULL){
      
        sprintf(name,"%s/%s",DirName,entry->d_name);
        stat(name,&sobj);
        
        ret = 0;
        fd2 = open(name,O_RDONLY);
        
        printf("_______\n");
        if(S_ISREG(sobj.st_mode)){
        
           printf("***\n");
          
           while((ret = read(fd2,buffer,sizeof(buffer)))!=0){
             
              write(fd1,buffer,ret);
           }
        }
       
       }
       
       closedir(dp);
       close(fd1);
       
   return 0;
   
}
