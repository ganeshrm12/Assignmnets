#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>

#pragma pack(1)

struct Employee 
{
 int EmpID;
 char Ename[20];
 float salary;
 int Age;
};


int main(int argc, char *argv[]){

struct Employee eobj;
char Fname[20];
int fd = 0;

eobj.EmpID = 11;
eobj.salary = 89.99f;
eobj.Age = 25;

strcpy(eobj.Ename,"SAHIL");

printf("Enter the file name : \n");
scanf("%s",Fname);

fd = creat(Fname,0777);
write(fd,&eobj,sizeof(eobj));

return 0;
}
