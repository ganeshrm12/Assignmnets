#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>

#define BLOCKSIZE 1024
int main(int argc, char *argv[]){


   if(argc!=2){
   
      printf("Insufficient arguments\n");
      return -1;
   }
   
   DIR *dp = NULL;
   struct dirent *entry = NULL;
   struct stat sobj;
   
   dp = opendir(argv[1]);
   if(dp==NULL){
    
     printf("unable to open directory\n");
     return -1;
     
   }
   
   char name[20];
   
   while((entry = readdir(dp))!=NULL){
      
        sprintf(name,"%s/%s",argv[1],entry->d_name);
        stat(name,&sobj);
        
        printf("%s %d\n",entry->d_name,sobj.st_size);
       
         if(sobj.st_size==0){
           
            printf("%s \n",entry->d_name);
            remove(name);
            
         }
       
       }
       
       closedir(dp);
   return 0;
   
}
