#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>

#define BLOCKSIZE 1024
int main(int argc, char *argv[]){


   if(argc!=3){
   
      printf("Insufficient arguments\n");
      return -1;
   }
   
   DIR *dp = NULL;
   struct dirent *entry = NULL;
   
   dp = opendir(argv[1]);
   if(dp==NULL){
    
     printf("unable to open directory\n");
     return -1;
     
   }
   
   int flag = 1;
   while((entry = readdir(dp))!=NULL){
      
        
        printf("%s \n",entry->d_name);
       
         if(strcmp(entry->d_name,argv[2])==0){
           
            flag = 0;
            printf("file is present in directory\n");
            break;
         }
       
       }
       if(flag==1){
       
          printf("file not present in directory\n");
       }
       closedir(dp);
   return 0;
   
}
