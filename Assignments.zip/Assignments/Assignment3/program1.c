#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>

#define BLOCKSIZE 1024
int main(int argc, char *argv[]){


   if(argc!=3){
   
      printf("Insufficient arguments\n");
      return -1;
   }
   
   int ret = 0;
   int fd1 = 0;
   int fd2 = 0;
   char Buffer[BLOCKSIZE] = {'\0'};
    
   fd1 = open(argv[1],O_RDONLY);
   fd2 = open(argv[2],O_RDWR);
   
   if(fd1==-1 || fd2== -1){
   
      printf("unable to open file %d , %d\n",fd1,fd2);
      return -1;
   }
   
   while((ret = read(fd1,Buffer,sizeof(Buffer)))!=0){
   
       write(fd2,Buffer,ret);
       
   }
   
   
   printf("File 1 successfully copied into file 2\n");
   
   close(fd1);
   close(fd2);
   
   return 0;
   
}
