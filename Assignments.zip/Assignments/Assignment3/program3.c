#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>

#define BLOCKSIZE 1024
int main(int argc, char *argv[]){


   if(argc!=3){
   
      printf("Insufficient arguments\n");
      return -1;
   }
   
   DIR *dp = NULL;
   struct dirent *entry = NULL;
   char source[20];
   char dest[20];
   
   
   dp = opendir(argv[1]);
   if(dp == NULL){
 
    printf("Unable to open directory\n");
    return -1;
    
 }
 
  while((entry = readdir(dp))!=NULL){
  
      sprintf(source,"%s/%s",argv[1],entry->d_name);
      sprintf(dest,"%s/%s",argv[2],entry->d_name);
      
      rename(source,dest);
  }
   
   
   closedir(dp);
   return 0;
   
}
