#include "sharedfile.h"
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
#include<sys/stat.h>

int compareFileContent(){

 int fd1 = 0;
 int fd2 = 0;
 struct stat obj1,obj2;
 char Buffer1[1024];
 char Buffer2[1024];
 int ret = 0;
 int iCnt = 0;
 char fname1[50];
 char fname2[50];
 
 printf("Enter first filename : ");
 scanf("%s",fname1);
 printf("Enter second filename : ");
 scanf("%s",fname2);
 
 fd1 = open(argv[1],O_RDONLY);
 fd2 = open(argv[2],O_RDONLY);
 
 if(fd1==-1 || fd2==-1){
 
   printf("Unable to open file\n");
   return -1;
 }
 
 //file is already open we can call fstat
 
 fstat(fd1,&obj1);
 fstat(fd2,&obj2);
 
 if(obj1.st_size != obj2.st_size){
 
    printf("Files are different as sizes are different\n");
    return -1;
 }
 
 while((ret = read(fd1, Buffer1, sizeof(Buffer1)))!=0)
 {
    printf("Iteration o : %d\n",iCnt);
    iCnt++;
    ret = read(fd2,Buffer2,sizeof(Buffer2));
    if(memcmp(Buffer1,Buffer2,ret)!=0){
    
       break;
    }
 }
 
 close(fd1);
 close(fd2);
 
 if(ret==0){
    return 0;
 }
  
 return -1;
}
