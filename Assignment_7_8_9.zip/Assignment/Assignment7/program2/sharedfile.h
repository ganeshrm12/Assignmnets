int compareFileContent();
