#include<stdio.h>
#include<stdlib.h>
#include<dlfcn.h>

int main(){

          void *ptr = NULL;
          int (*fptr)();
          
          ptr = dlopen("/home/ganesh/Desktop/Assignments/Assignment7/program2/library.so",RTLD_LAZY);
          
          if(ptr == NULL){
           
            printf("Unable to load library");
            return -1;
          }
          
          fptr = dlsym(ptr,"compareFileContent");
          if(fptr==NULL){
            
            printf("Unable to load address of function\n");
            return -1;
            
          }
          if(fptr()==0){
            printf("Both files are identical\n");
         }else{
           printf("Both files are different\n");
            }
          
          printf("----Thank you!!----\n");
}
