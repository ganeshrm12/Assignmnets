_Bool isPrimeNumber(int);
