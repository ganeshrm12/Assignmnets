_Bool isPerfect(int);
