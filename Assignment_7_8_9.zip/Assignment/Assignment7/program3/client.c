#include<stdio.h>
#include<stdlib.h>
#include<dlfcn.h>
#include<stdbool.h>

int main(){

          void *ptr = NULL;
          _Bool (*fptr1)(int);
          _Bool (*fptr2)(int);
          
          ptr = dlopen("/home/ganesh/Desktop/Assignments/Assignment7/program3/libraryPrime.so",RTLD_LAZY);
          
          if(ptr == NULL){
           
            printf("Unable to load libraryPrime");
            return -1;
          }
          
          int num;
          printf("Enter number : ");
          scanf("%d", &num);
          
          fptr1 = dlsym(ptr,"isPrimeNumber");
          if(fptr1==NULL){
            
            printf("Unable to load address of function isPrime\n");
            return -1;
            
          }    
          
          if(fptr1(num)){
           
             printf("Number is prime\n");
          }else{
             printf("Number is not prime\n");
          }
          
           ptr = dlopen("/home/ganesh/Desktop/Assignments/Assignment7/program3/libraryPerfect.so",RTLD_LAZY);
          
           if(ptr == NULL){
           
            printf("Unable to load libraryPerfect");
            return -1;
          }
          
          fptr2 = dlsym(ptr,"isPerfect");
          
          if(fptr2==NULL){
            
            printf("Unable to load address of function isPerfect\n");
            return -1;
            
          }    
          
          if(fptr2(num)){
           
             printf("Number is perfect\n");
          }else{
             printf("Number is not perfect\n");
          }
          
          printf("----Thank you!!----\n");
}
