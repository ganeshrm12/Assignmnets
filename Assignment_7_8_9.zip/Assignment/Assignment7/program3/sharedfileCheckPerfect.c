#include "sharedfileCheckPerfect.h"
#include<stdio.h>
#include<stdbool.h>
_Bool isPerfect(int num){

   int rem=0,sum=0;
   
   for(int i=1; i<num; i++){
    
       rem = num%i;
       if(rem==0){
        
         sum =  sum + i;
         
       }
   }
   
    if(sum == num)
       return true;
    else
       return false;   
}
