#include "sharedfileCheckPrime.h"
#include<stdio.h>
#include<stdbool.h>

_Bool isPrimeNumber(int num){


     if(num==2 || num==3){
        return true;
     }
    for(int i=2; i<=num/2; i++){
      
         if(num%i==0){
           
            return false;
         }
    }
    
    return true;
}
