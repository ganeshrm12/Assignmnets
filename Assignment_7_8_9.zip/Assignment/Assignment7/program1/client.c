#include<stdio.h>
#include<stdlib.h>
#include<dlfcn.h>

int main(){

   int choice,num1,num2;
   
   printf("Select operation : \n 1. Additon\n 2. Subtraction\n 3. Division\n 4. Multiplication\n");
   scanf("%d",&choice);
   
   printf("Enter num1 : ");
   scanf("%d",&num1);
   
   printf("Enter num2 : ");
   scanf("%d",&num2);
   
   void *ptr = NULL;
   int (*fptr)(int,int);
   
   ptr = dlopen("/home/ganesh/Desktop/Assignments/Assignment7/program1/library.so",RTLD_LAZY);  
   
   if(ptr == NULL){
    
       printf("Unable to load library\n");
       return -1;
   }
   
   int ans = 0;
   switch(choice){
   
     case 1 : 
          fptr = dlsym(ptr,"Addition"); 
          if(fptr==NULL){
            printf("Unable to load the address of function");
            return -1;
          }
          ans = fptr(num1,num2);
          printf("Addition is : %d\n",ans); 
          break; 
          
    case 2 : 
          fptr = dlsym(ptr,"Subtraction"); 
          if(fptr==NULL){
            printf("Unable to load the address of function");
            return -1;
          }
          ans = fptr(num1,num2);
          printf("Subtraction is : %d\n",ans); 
          break;
     
     case 3 : 
          fptr = dlsym(ptr,"Division"); 
          if(fptr==NULL){
            printf("Unable to load the address of function");
            return -1;
          }
          ans = fptr(num1,num2);
          printf("Division is : %d\n",ans); 
          break;  
     
     case 4 : 
          fptr = dlsym(ptr,"Multiplication"); 
          if(fptr==NULL){
            printf("Unable to load the address of function");
            return -1;
          }
          ans = fptr(num1,num2);
          printf("Multiplication is : %d\n",ans); 
          break;      
   
      default :
        printf("Invalid choice\n");
        break;  
}
          printf("----Thank you!!----\n");
}
