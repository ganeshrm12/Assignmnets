int Addition(int,int );
int Subtraction(int,int);
int Division(int,int);
int Multiplication(int,int);
