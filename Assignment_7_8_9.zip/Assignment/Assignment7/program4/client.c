#include<stdio.h>
#include<stdlib.h>
#include<dlfcn.h>


int main(){

    void *ptr1 = NULL;
    void (*fptr1)();
    int number = 0;
    
    printf("Enter number : ");
    scanf("%d",&number);
    
    ptr1 = dlopen("/home/ganesh/Desktop/Assignments/Assignment7/program4/externalLibrary.so",RTLD_LAZY);
    if(ptr1==NULL){
     
        printf("Unable to load library\n");
        return -1;
    }
    
    fptr1 = dlsym(ptr1,"findfactorial");
    if(fptr1 == NULL){
     
        printf("Unable to load address of function");
        return -1;
    }
    
      printf("Value of number is %d\n",number);
      fptr1(&number);
      return 0;
}
