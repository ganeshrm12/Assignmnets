int findfactorial(int *);
