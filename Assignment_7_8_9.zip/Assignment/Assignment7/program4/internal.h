void factorial(int *);
