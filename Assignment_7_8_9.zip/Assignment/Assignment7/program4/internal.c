#include<stdio.h>
#include "internal.h"

void factorial(int *num){

   int fact = 1;
   int n = *num;
   printf("Value of num is %d\n",*num);
   
   for(int i=n; i>0; i--){
    
      fact = fact*i;
   }
   
   printf("factorial of %d is %d\n",n,fact);
}

