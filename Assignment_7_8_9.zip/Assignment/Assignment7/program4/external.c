#include<stdio.h>
#include<stdlib.h>
#include<dlfcn.h>
#include "external.h"


int findfactorial(int *n){

    void *ptr = NULL;
    void (*fptr)();
    
    printf("==Value of n is %d\n",*n);
    
    ptr = dlopen("/home/ganesh/Desktop/Assignments/Assignment7/program4/internalLibrary.so",RTLD_LAZY);
    if(ptr==NULL){
     
        printf("Unable to load library\n");
        return -1;
    }
    
    fptr = dlsym(ptr,"factorial");
    if(fptr == NULL){
     
        printf("Unable to load address of function");
        return -1;
    }
    
    printf("Value of n is %d\n",*n);
    int tmp;
    tmp = *n;
    fptr(&tmp);
    return 0;
}
