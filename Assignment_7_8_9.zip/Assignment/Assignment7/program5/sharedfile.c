#include "sharedfile.h"
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>

void DisplayFileInfo(char* filename){
 
    struct stat sobj;
    
    stat(filename,&sobj);
    
    printf("Filename : %s\n",filename);
    printf("File size : %ld\n",sobj.st_size);
    printf("Number of links : %ld\n",sobj.st_nlink);
    printf("Inode number : %ld\n",sobj.st_ino);
}
