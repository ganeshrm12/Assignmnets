void DisplayFileInfo(char *);
