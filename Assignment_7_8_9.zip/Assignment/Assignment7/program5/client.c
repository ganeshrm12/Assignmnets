#include<stdio.h>
#include"sharedfile.h"

int main(){

  char fname[20];
  printf("Enter filename : ");
  scanf("%s",&fname);
  
  DisplayFileInfo(fname);
  
}
