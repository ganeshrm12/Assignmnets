#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){
 
 int Ret = 0;

 int status1 = 0;
 
 Ret = fork();
 
 if(Ret==0){
 
    execl("./Process2","NULL",NULL);
    
 }else{
    
    //wait(&status1);
    printf("Main Parent process1 is running\n");
    printf("process1->pid = %d and ppid= %d\n",getpid(),getppid());
    printf("child of process1 is PID = %d\n",Ret);
 }
 
 return 0;

}

/*
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ ./Myexe

Process 3 is running which created by process2
process3->pid = 11526 and ppid= 11525
process2 is running
process2->pid = 11525 and ppid= 11524
child of process2 is PID = 11526
Main Parent process1 is running
process1->pid = 11524 and ppid= 11069
child of process1 is PID = 11525

*/
