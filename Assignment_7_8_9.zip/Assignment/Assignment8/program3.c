#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){
 
 int Ret1 = 0, Ret2=0, Ret3=0;
 int status1 = 0;
 int status2 = 0;
 int status3 = 0;
 
 Ret1 = fork();
 
 if(Ret1==0){
   
   //wait(&status1);
    printf("Child process2 is running pid-> %d and ppid->%d\n",getpid(),getppid());
    
 }else{
    
    //wait(&status2);
    Ret2 = fork();
    
    if(Ret2==0){
      
       printf("child process 3 is running pid-> %d and ppid->%d\n",getpid(),getppid());
    }
    else{
      
       //wait(&status3);
       Ret3 = fork();
       
       if(Ret3==0){
         
          printf("child process 4 is running pid-> %d and ppid->%d\n",getpid(),getppid());
       }
    } 
  
   wait(&status1);
   wait(&status2);
   wait(&status3);
    printf("Parent process1 is running pid-> %d and ppid->%d\n",getpid(),getppid());
 }
 
 return 0;

}


