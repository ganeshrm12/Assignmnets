#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>

int main(){
 
  int fd = 0;
  pid_t pid = 0;
  
  pid = fork();
  
  if(pid<0){
  
     printf("fork failed\n");
     exit(1);
  }
  
  if(pid>0){
   
     printf("pid of child process %d\n",pid);
     exit(0);
  }
   
   fd = open("log.txt",O_RDWR);
   
   char buffer[20];
   
   
   while(1){
   
     sleep(1);
     write(fd,"logging...",10);
   }
   
   close(fd);
  return 0;
}

/*
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ gcc program5.c -o Myexe
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ ./deamon
pid of child process 3227
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ ps
    PID TTY          TIME CMD
   3142 pts/1    00:00:00 bash
   3227 pts/1    00:00:00 deamon
   3262 pts/1    00:00:00 ps
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ kill deamon
bash: kill: Myexe: arguments must be process or job IDs
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ kill 3227
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ ps
    PID TTY          TIME CMD
   3142 pts/1    00:00:00 bash
   3272 pts/1    00:00:00 ps
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ ^C

*/
