#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){
 
int Ret = 0;
//int pid2 = 0
Ret = fork();
int status = 0;
 if(Ret==0){
 
     printf("Process 3 is running which created by process2\n");
     printf("process3->pid = %d and ppid= %d\n",getpid(),getppid()); 
  
  }else{
   
    //wait(&status);
    printf("process2 is running\n");
    printf("process2->pid = %d and ppid= %d\n",getpid(),getppid());
    printf("child of process2 is PID = %d\n",Ret);
    
  }
 
 return 0;

}


