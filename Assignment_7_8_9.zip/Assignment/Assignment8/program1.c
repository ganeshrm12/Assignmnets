#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){
 
 int Ret = 0;
 int status = 0;
 
 Ret = fork();
 
 if(Ret==0){
    //wait(&status);
    printf("Child process is running\n");
    
 }else{
    wait(&status);
    printf("Parent process is running\n");
 }
 
 return 0;

}

/*
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ ./Myexe   //without wait
Parent process is running
Child process is running
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ ./Myexe   //after wait 
Child process is running
Parent process is running

*/
