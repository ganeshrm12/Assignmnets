#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){
 
 pid_t pid1, pid2;
 int status;
 pid1 = fork();
 
 if(pid1 == 0){
    printf("child1 process1 running\n");
 }
 
 if(pid1>0){
  
    pid2 = fork();
    
    if(pid2==0){
        printf("child2 process2 running\n");
     }
    
    if(pid2>0){
       wait(&status);
       printf("parent2 is running\n");
    } 
 }
 
 return 0;

}

/*
ganesh@Ubuntu:~/Desktop/Assignments/Assignment8$ ./Myexe
child1 process1 running
child2 process2 running
parent2 is running

*/
