#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/resource.h>
#include<fcntl.h>

int main(){

   char *s = getenv("HOME");
   char *username = getenv("USERNAME");
   
   printf("Environment of running process is : \n");
   
   printf("home directory : %s\n",s);
   printf("username : %s\n",username);
   
   return 0;
}
