#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/resource.h>
#include<fcntl.h>

int main(){

   int ret = 0;
   
   ret = getpriority(PRIO_PROCESS,0);
   
   printf("old priority is %d\n",ret);
   
   //ret = nice(-10);
   
   printf("new priority is %d\n",getpriority(PRIO_PROCESS,5));
   
   return 0;
   
}
