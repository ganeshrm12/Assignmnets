#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/resource.h>
#include<fcntl.h>

int main(){

   int ret = 0;
   
   ret = getpriority(PRIO_PROCESS,0);
   
   printf("priority is %d\n",ret);
   
   return 0;
   
}
