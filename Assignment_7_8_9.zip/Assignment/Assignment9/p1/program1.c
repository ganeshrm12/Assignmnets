#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

int main(){

   int pid  = 0;
   int status = 0;
   
   pid  = fork();
   if(pid==0){
       
        execl("./filenamesprocess","NULL",NULL);
       
   }else{
    
       wait(&status);
       printf("In parent\n");
       
   }

   return 0;
   
}
