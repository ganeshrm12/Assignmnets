#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<dirent.h>
#include<sys/stat.h>

int main(){

   DIR *dr;
   struct dirent *en;
   int fd = 0;
   char str[20];
   char sname[20];
   struct stat sobj;
   
   dr = opendir("/home/ganesh/Desktop");
   
   fd = open("filelist.txt",O_CREAT|O_RDWR,0777);
   
   if(dr){
    
      while((en = readdir(dr))!= NULL){
      
       sprintf(str,"%s\n",en->d_name);
       int ret = 0;
       ret = write(fd,str,strlen(str));
       //printf("ret = %d\n",ret);
       //printf("%s and %d\n",str,strlen(str));  
      
         
      }
      
      close(fd);
      closedir(dr);
   }

   return 0;
   
}
