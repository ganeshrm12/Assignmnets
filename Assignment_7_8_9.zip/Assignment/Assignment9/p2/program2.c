//Demonstration of Multiprocessing

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/resource.h>
#include<fcntl.h>

int main(){


   int ret1 = 0, ret2 = 0;
   int status = 0;
   
   ret1 = fork();
   if(ret1==0){
       wait(&status);
        execl("./process1","NULL",NULL);
    }
   
   ret2 = fork();
   if(ret2 ==0){
        wait(&status);
        execl("./process2","NULL",NULL);
   }
     wait(&status);
     printf("END");
   return 0;
   
}
