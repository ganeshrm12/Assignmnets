#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/resource.h>
#include<fcntl.h>
#include<string.h>
#include<sys/types.h>
int main(){

  int ret = 0;
  int fd = 0, fd1 = 0;
  char buffer[512];
  int cnt = 0;
  
  
   fd = open("Hello.txt",O_RDWR);
   fd1 = open("count.txt",O_RDWR);
   
   while((ret = read(fd,buffer,sizeof(buffer)))!=0){
       
     //  write(1,buffer,ret);
    //   cnt++;
    
    for(int i=0; i<ret; i++){
             
            if((buffer[i]>='A')&&(buffer[i]<='Z'))
            {
             
               cnt++;
            }
       }
             
      }
       
   printf("Number of capital character are from Hello.txt %d\n",cnt);
   char buff[30];
   sprintf(buff,"count is %d from Hello.txt\n",cnt);
   lseek(fd1,0,SEEK_END);
   write(fd1,buff,strlen(buff));
   
   return 0;
   
   close(fd);
   close(fd1);
   
   return 0;
   
}
